# PID of current job: 1814920
mSet<-InitDataObjects("specbin", "stat", FALSE, 150)
mSet<-Read.TextData(mSet, "Replacing_with_your_file_path", "rowu", "disc");
mSet<-SanityCheckData(mSet)
mSet<-PerformSanityClosure (mSet);
mSet<-CheckContainsBlank(mSet)
mSet<-FilterVariable(mSet, "F", 20, "none", -1, "mean", 0, F,10.0)
mSet<-PreparePrenormData(mSet)
mSet<-Normalization(mSet, "NULL", "LogNorm", "AutoNorm", ratio=FALSE, ratioNum=20)
mSet<-PlotNormSummary(mSet, "norm_0_", "png", 150, width=NA)
mSet<-PlotSampleNormSummary(mSet, "snorm_0_", "png", 150, width=NA)
mSet<-Ttests.Anal(mSet, F, 0.05, FALSE, TRUE, "fdr", FALSE)
mSet<-PlotTT(mSet, "tt_0_", "png", 150, width=NA)
mSet<-PCA.Anal(mSet)
mSet<-PlotPCAPairSummaryMeta(mSet, "pca_pair_0_", "png", 96, width=NA, 5, "NA", "NA")
mSet<-PlotPCAScree(mSet, "pca_scree_0_", "png", 150, width=NA, 5)
mSet<-PlotPCA2DScore(mSet, "pca_score2d_0_", "png", 150, width=NA, 1,2,0.95,0,0, "na")
mSet<-PlotPCALoading(mSet, "pca_loading_0_", "png", 150, width=NA, 1,2);
mSet<-PlotPCABiplot(mSet, "pca_biplot_0_", "png", 150, width=NA, 1,2,10)
mSet<-PlotPCA3DLoading(mSet, "pca_loading3d_0_", "json", 1,2,3)
mSet<-RF.Anal(mSet, 500,7,1)
mSet<-PlotRF.Classify(mSet, "rf_cls_0_", "png", 150, width=NA)
mSet<-PlotRF.VIP(mSet, "rf_imp_0_", "png", 150, width=NA)
mSet<-PlotRF.Outlier(mSet, "rf_outlier_0_", "png", 150, width=NA)
